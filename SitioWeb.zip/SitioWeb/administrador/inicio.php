<?php include('template/cabecera.php');?>
            <div class="col-md-12">
                   <div class="jumbotron">
                    <h1 class="display-3">Bienvenido <?php echo $nombreUsuario;?></h1>
                    <p class="lead">Desde este lugar vamos a administrar los libros del sitio web</p>
                    <hr class="my-2">
                    <p>More info</p>
                    <p class="lead">
                        <a class="btn btn-primary btn-lg" href="seccion/libros.php" role="button">Administrar los libros</a>
                </p>
            </div>
        </div>
<?php include('template/pie.php');?>
