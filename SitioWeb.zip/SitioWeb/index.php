<?php include("template/cabecera.php");?>
            <div class="jumbotron text-center">
                <h1 class="display-3">Bienvenido</h1>
                <p class="lead">Es increible que estemos al alcance de varias personas como lo eres tu 
                    y queremos que sepas que eres importante para nosotros como comunidad
                </p>
                <hr class="my-2">
                <img width="700" src="imagenes/AMAIA.png" class="img-thumbnail rounded mx-auto d-block"/>
                <p class="lead">
                    <a class="btn btn-primary btn-lg" href="libros.php" role="button">Ver imagenes</a>
                </p>
            </div>
<?php include("template/pie.php");?>