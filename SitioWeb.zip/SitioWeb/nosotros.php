<?php include("template/cabecera.php");?>

<div class="jumbotron">
    <h1 class="display-3">NOSOTROS</h1>
    <p class="lead">Somos un grupo de lectores interesados en que nuestras imagenes sean compartidas</p>
    <hr class="my-2">
</div>
<?php include("template/pie.php");?>