<?php include("template/cabecera.php");?>
<?php 
include("administrador/configuracion/bd.php");
$sentenciaSQL= $conexion->prepare("SELECT * FROM libros");
$sentenciaSQL->execute();
$listaLibros=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
?>
<?php foreach($listaLibros as $libro){?>
<div class="col-md-3">
<div class="card">
    <img class="card-img-top" src="./imagenes/<?php echo $libro['Imagen'];?>" alt="">
    <div class="card-body">
        <h4 class="card-title"><?php echo $libro['Nombre'];?></h4>
        <a name="" id="" class="btn btn-primary" href="https://drive.google.com/drive/folders/15eXy2D_K8-hoqyxu3yRhv1RzICOpsVyV?usp=sharing" role="button">Descagar del folder</a>
    </div>
</div>
</div>
<?php }?>

<?php include("template/pie.php");?>